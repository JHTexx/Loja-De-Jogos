package com.lojadejogos.model;

public interface Autenticavel {
    boolean autenticar(String senha);
}